/*
 * ov5640.c
 *
 *  Created on: 7 июн. 2026 г.
 *      Author: Alex
 */


// ov5640.c
#include "ov5640.h"
#include "dcmi.h"   // HAL DCMI драйвер
#include "i2c.h"    // HAL I2C драйвер

// Глобальные переменные
//uint32_t  g_camera_frame[IMAGE_DMA_WORDS] __attribute__((aligned(32)));
uint32_t  g_camera_frame[IMAGE_DMA_WORDS] __attribute__((section(".camera_buffer"), aligned(32)));

// Прототипы
static uint8_t OV5640_WriteRegister(uint16_t reg, uint8_t data);
static uint8_t OV5640_ReadRegister(uint16_t reg, uint8_t *data);
static void OV5640_Config_JPEG(void); // Для продвинутого режима
static void OV5640_Config_RGB565(void); // Наш целевой режим


extern I2C_HandleTypeDef hi2c1;


//#define OV5640_ADDR 0x3C


uint8_t OV5640_WriteReg(uint16_t reg, uint8_t data)
{
    uint8_t buffer[3];
    buffer[0] = (reg >> 8) & 0xFF;  // Старший байт адреса
    buffer[1] = reg & 0xFF;         // Младший байт адреса
    buffer[2] = data;               // Данные

    HAL_StatusTypeDef status = HAL_I2C_Master_Transmit(&hi2c1, OV5640_ADDR , buffer, 3, 100);

    if (status != HAL_OK)
    {
        // Обработка ошибки
        return 1;
    }
    return 0;
}

/**
  * @brief  Чтение байта из регистра OV5640
  * @param  reg: 16-битный адрес регистра
  * @retval Прочитанное значение
  */
uint8_t OV5640_ReadReg(uint16_t reg)
{
    uint8_t reg_addr[2];
    uint8_t data = 0;

    reg_addr[0] = (reg >> 8) & 0xFF;
    reg_addr[1] = reg & 0xFF;

    // Отправляем адрес регистра
    HAL_I2C_Master_Transmit(&hi2c1, OV5640_ADDR, reg_addr, 2, 100);
    // Читаем данные
    HAL_I2C_Master_Receive(&hi2c1, OV5640_ADDR, &data, 1, 100);

    return data;
}

/**
  * @brief  Чтение ID камеры
  * @retval ID камеры (должно быть 0x5640)
  */
uint16_t OV5640_ReadID1(void)
{
    uint16_t pid = 0;
    pid = OV5640_ReadReg(0x300A);
    pid = (pid << 8) | OV5640_ReadReg(0x300B);
    return pid;
}






// Функция записи в регистр (эмуляция SCCB через I2C)
static uint8_t OV5640_WriteRegister(uint16_t reg, uint8_t data) {
    uint8_t buf[3];
    buf[0] = (reg >> 8) & 0xFF;
    buf[1] = reg & 0xFF;
    buf[2] = data;
    // HAL_I2C_Master_Transmit(handle, slave_addr, data, size, timeout)
    // Сдвигаем адрес влево на 1, т.к. HAL ждет 7-битный адрес без бита RW
    if (HAL_I2C_Master_Transmit(&hi2c1, OV5640_ADDR, buf, 3, HAL_MAX_DELAY) != HAL_OK)
        return 1;
    return 0;
}

// Чтение регистра
static uint8_t OV5640_ReadRegister(uint16_t reg, uint8_t *data) {
    uint8_t buf[2];
    buf[0] = (reg >> 8) & 0xFF;
    buf[1] = reg & 0xFF;
    if (HAL_I2C_Master_Transmit(&hi2c1, OV5640_ADDR , buf, 2, HAL_MAX_DELAY) != HAL_OK)
        return 1;
    if (HAL_I2C_Master_Receive(&hi2c1, OV5640_ADDR , data, 1, HAL_MAX_DELAY) != HAL_OK)
        return 1;
    return 0;
}

// Проверка ID (главная проверка, что камера жива)
uint8_t OV5640_ReadID(uint16_t *DeviceID) {
    uint8_t high = 0, low = 0;
    if (OV5640_ReadRegister(0x300A, &high)) return 1;
    if (OV5640_ReadRegister(0x300B, &low)) return 1;
    *DeviceID = (high << 8) | low;
    return 0;
}


// Базовая инициализация (заливка регистров)
uint8_t OV5640_Init(void) {
    uint16_t id = 0;

 // 2. Проверка ID камеры (должно быть 0x5640)
    uint16_t pid = 0;
    pid = OV5640_ReadReg(0x300A); // Читаем старший байт PID
    pid = (pid << 8) | OV5640_ReadReg(0x300B);
    if (pid != 0x5640) return 1; // Ошибка: камера не отвечает

    // Задержка для стабилизации питания
    HAL_Delay(20);
    // Сброс
    OV5640_WriteReg(0x3103, 0x11);  // system clock from pad, bit[1]
    OV5640_WriteReg(0x3008, 0x82);
    HAL_Delay(5);  // Критически важная задержка после сброса!


    // 2. Выключить питание (Software Power Down) на время всей остальной настройки
    //OV5640_WriteReg(0x3008, 0x42);
    HAL_Delay(5);




    for (uint32_t i = 0; i < ov5640_default_regs_size; i++)
    {
        uint16_t reg =
            ((uint16_t)ov5640_default_regs[i][0] << 8) |
            ov5640_default_regs[i][1];

        uint8_t value = ov5640_default_regs[i][2];

        if (OV5640_WriteReg(reg, value) != 0)
        {
            return 3;
        }

        if (reg == 0x3008)
        {
            HAL_Delay(20);
        }
    }


    // 4. ВКЛЮЧИТЬ КАМЕРУ (Software Power Up) - САМЫЙ ВАЖНЫЙ ШАГ!
   // OV5640_WriteReg(0x3008, 0x02);

    HAL_Delay(100);



    if (pid != 0x5640) return 1; // Ошибка: камера не отвечает
    // Проверяем ID. Если чтение не удалось (HAL_BUSY или ошибка) — камера не отвечает.
    if (OV5640_ReadID(&id) != 0) {
        return 1; // Ошибка I2C
    }

    if (id != 0x5640) {
        return 2; // Неверный ID (возможно, другая камера)
    }



    return 0;
}


extern uint32_t debug_dma_irq_count;   // объявлена в stm32h7xx_it.c: подгоните тип/volatile под её объявление
extern volatile uint8_t g_camera_error; // объявлена в main.c

volatile uint32_t dbg_start_status;     // результат HAL_DCMI_Start_DMA (0 = HAL_OK, 1 = ERROR, 2 = BUSY, 3 = TIMEOUT)
volatile uint32_t dbg_ndtr;             // DMA1_Stream0->NDTR (62500 = DMA ни разу не принял слово)
volatile uint32_t dbg_dma_en;           // 1 = стрим DMA включён
volatile uint32_t dbg_lisr;             // DMA1->LISR целиком
volatile uint32_t dbg_dma_teif;         // 1 = ошибка обращения DMA к памяти
volatile uint32_t dbg_dma_dmeif;        // 1 = ошибка прямого режима
volatile uint32_t dbg_dma_feif;         // 1 = ошибка FIFO
volatile uint32_t dbg_dcmi_cr;          // DCMI->CR целиком
volatile uint32_t dbg_dcmi_enable;      // бит 14 (должен быть 1)
volatile uint32_t dbg_dcmi_capture;     // бит 0 (должен быть 1)
volatile uint32_t dbg_dcmi_cm;          // бит 1 (0 = continuous)
volatile uint32_t dbg_dcmi_sr;          // DCMI->SR (бит0 HSYNC, бит1 VSYNC, уже с учётом полярности)
volatile uint32_t dbg_dcmi_risr;        // DCMI->RISR (бит0 FRAME, бит1 OVR, бит2 ERR, бит3 VSYNC, бит4 LINE)
volatile uint32_t dbg_dcmi_ovr;         // 1 = переполнение DCMI
volatile uint32_t dbg_dcmi_err;         // 1 = ошибка синхронизации
volatile uint32_t dbg_hdcmi_error;      // hdcmi.ErrorCode
volatile uint32_t dbg_hdma_error;       // hdma_dcmi.ErrorCode
volatile uint32_t dbg_irq_count;        // debug_dma_irq_count
volatile uint32_t dbg_camera_error;     // g_camera_error
volatile uint32_t dbg_changed_words;    // сколько слов буфера уже не равны 0xA5A5A5A5


// Запуск захвата DMA через HAL
void OV5640_StartCapture(void) {
    //g_frame_capture_complete = 0;

    // Запуск DCMI в режиме одиночного снимка (Snapshot) DCMI_MODE_SNAPSHOT   DCMI_MODE_CONTINUOUS
    // Адрес буфера, размер в байтах (преобразуем кол-во пикселов -> байты)

	HAL_StatusTypeDef capture_status;
	capture_status = HAL_DCMI_Start_DMA(&hdcmi,DCMI_MODE_SNAPSHOT, (uint32_t)g_camera_frame,IMAGE_DMA_WORDS);

	HAL_Delay(200);

	extern volatile uint32_t dbg_dcmi_ier, dbg_dcmi_nvic_en;
	dbg_dcmi_ier     = DCMI->IER;
	dbg_dcmi_nvic_en = NVIC_GetEnableIRQ(DCMI_IRQn);
	volatile uint32_t dbg_hdcmi_state = hdcmi.State;
	volatile uint32_t dbg_dma_mode    = hdma_dcmi.Init.Mode;

	dbg_ndtr        = DMA1_Stream0->NDTR;
	    dbg_dma_en      = (DMA1_Stream0->CR & DMA_SxCR_EN) ? 1U : 0U;

	    dbg_lisr        = DMA1->LISR;
	    dbg_dma_teif    = (dbg_lisr & DMA_LISR_TEIF0)  ? 1U : 0U;
	    dbg_dma_dmeif   = (dbg_lisr & DMA_LISR_DMEIF0) ? 1U : 0U;
	    dbg_dma_feif    = (dbg_lisr & DMA_LISR_FEIF0)  ? 1U : 0U;

	    dbg_dcmi_cr      = DCMI->CR;
	    dbg_dcmi_enable  = (dbg_dcmi_cr & DCMI_CR_ENABLE)  ? 1U : 0U;
	    dbg_dcmi_capture = (dbg_dcmi_cr & DCMI_CR_CAPTURE) ? 1U : 0U;
	    dbg_dcmi_cm      = (dbg_dcmi_cr & DCMI_CR_CM)      ? 1U : 0U;

	    dbg_dcmi_sr     = DCMI->SR;
	    dbg_dcmi_risr   = DCMI->RISR;
	    dbg_dcmi_ovr    = (dbg_dcmi_risr & DCMI_RIS_OVR_RIS) ? 1U : 0U;
	    dbg_dcmi_err    = (dbg_dcmi_risr & DCMI_RIS_ERR_RIS) ? 1U : 0U;

	    dbg_hdcmi_error = hdcmi.ErrorCode;
	    dbg_hdma_error  = hdma_dcmi.ErrorCode;

	    dbg_irq_count    = debug_dma_irq_count;
	    dbg_camera_error = g_camera_error;

	    dbg_changed_words = 0;
	    for (uint32_t i = 0; i < IMAGE_DMA_WORDS; i++) {
	        if (g_camera_frame[i] != 0xA5A5A5A5UL) dbg_changed_words++;
	    }



	    int j=1;
}

void OV5640_StopCapture(void) {
    HAL_DCMI_Stop(&hdcmi);
}


